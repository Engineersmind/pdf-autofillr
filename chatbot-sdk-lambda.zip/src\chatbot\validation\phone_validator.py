# chatbot/validation/phone_validator.py
"""Phone number validation."""
from __future__ import annotations
import re

PHONE_RE = re.compile(r"^\+?[\d\s\-().]{7,20}$")


def validate_phone(value: str) -> bool:
    """Return True if value looks like a valid phone number."""
    if not value:
        return False
    cleaned = value.strip()
    return bool(PHONE_RE.match(cleaned))


def normalise_phone(value: str) -> str:
    """Strip extra whitespace and normalise common separators."""
    return re.sub(r"\s+", " ", value.strip())
