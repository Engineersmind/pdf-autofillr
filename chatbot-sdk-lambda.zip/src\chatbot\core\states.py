# chatbot/core/states.py
"""
State enum — the 13 conversation states.
"""

from enum import Enum


class State(str, Enum):
    INIT = "init"
    SAVED_INFO_CHECK = "saved_info_check"
    INVESTOR_TYPE_SELECT = "investor_type_select"
    DATA_COLLECTION = "data_collection"
    CONTINUE_PROMPT = "continue_prompt"
    UPDATE_EXISTING_PROMPT = "update_existing_prompt"
    ANOTHER_INFO_PROMPT = "another_info_prompt"
    MISSING_FIELDS_PROMPT = "missing_fields_prompt"
    MAILING_ADDRESS_CHECK = "mailing_address_check"
    SEQUENTIAL_FILL = "sequential_fill"
    BOOLEAN_GROUP_SELECT = "boolean_group_select"
    OPTIONAL_FIELDS_PROMPT = "optional_fields_prompt"
    COMPLETE = "complete"


# Investor types supported
INVESTOR_TYPES = [
    "Individual",
    "Corporation",
    "Partnership",
    "Trust",
    "LLC",
    "Joint Account",
    "IRA",
    "Pension Fund",
    "Foundation",
    "Endowment",
]

# Map investor type display name → form_keys filename
INVESTOR_TYPE_FILES = {
    "Individual": "form_keys_individual.json",
    "Corporation": "form_keys_corporation.json",
    "Partnership": "form_keys_partnership.json",
    "Trust": "form_keys_trust.json",
    "LLC": "form_keys_llc.json",
    "Joint Account": "form_keys_joint_account.json",
    "IRA": "form_keys_ira.json",
    "Pension Fund": "form_keys_pension_fund.json",
    "Foundation": "form_keys_foundation.json",
    "Endowment": "form_keys_endowment.json",
}
