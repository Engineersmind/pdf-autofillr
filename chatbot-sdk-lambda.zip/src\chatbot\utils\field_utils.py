# chatbot/utils/field_utils.py
"""Missing fields detection, field classification, and resolution."""
from __future__ import annotations
from typing import List, Tuple


def get_missing_mandatory_keys(live_fill_flat: dict, mandatory_flat: dict) -> List[str]:
    """Return mandatory field keys that have not been filled yet."""
    missing = []
    for key in mandatory_flat:
        val = live_fill_flat.get(key)
        if val is None or val == "":
            missing.append(key)
    return missing


def get_optional_fields(live_fill_flat: dict, mandatory_flat: dict) -> List[str]:
    """Return fields that are present in live_fill_flat but not in mandatory_flat and still empty."""
    mandatory_keys = set(mandatory_flat.keys())
    return [
        k for k, v in live_fill_flat.items()
        if k not in mandatory_keys and (v is None or v == "")
    ]


def classify_fields_by_type(field_keys: List[str], meta_form_keys: dict) -> Tuple[List[str], List[str]]:
    """
    Split field_keys into (boolean_fields, text_fields).
    Uses meta_form_keys to determine type.
    """
    booleans, texts = [], []
    for key in field_keys:
        ftype = _get_field_type(key, meta_form_keys)
        if ftype == "boolean":
            booleans.append(key)
        else:
            texts.append(key)
    return booleans, texts


def _get_field_type(field_key: str, meta_form_keys: dict) -> str:
    """Lookup field type in meta_form_keys. Defaults to 'text'."""
    parts = field_key.split(".")
    node = meta_form_keys
    for part in parts:
        if isinstance(node, dict):
            node = node.get(part, {})
        else:
            return "text"
    if isinstance(node, dict):
        return node.get("type", "text")
    return "text"


def format_field_name(key: str) -> str:
    """Convert a field path to a human-readable label."""
    parts = key.split(".")
    last = parts[-1].replace("_id", "").replace("_check", "")
    return last.replace("_", " ").title()
