# chatbot/handlers/investor_type_handler.py
"""Handles INVESTOR_TYPE_SELECT state."""
from __future__ import annotations
from typing import Optional, Tuple
from fuzzywuzzy import process as fuzz_process
from chatbot.core.states import State, INVESTOR_TYPES
from chatbot.handlers.base_handler import BaseHandler
from chatbot.utils.dict_utils import flatten_dict


class InvestorTypeHandler(BaseHandler):
    def handle(self, session, user_input, user_id, session_id, debug=None):
        investor_type = self._parse_selection(user_input)
        if not investor_type:
            lines = ["I didn't recognise that. Please choose a number or type the investor type:\n"]
            for i, t in enumerate(INVESTOR_TYPES, 1):
                lines.append(f"  {i}. {t}")
            msg = "\n".join(lines)
            self._log_turn(session, user_input, msg, State.INVESTOR_TYPE_SELECT.value)
            return msg, State.INVESTOR_TYPE_SELECT

        form_keys = self.form_config.get_form_keys_for_type(investor_type)
        mandatory = self.form_config.get_mandatory_fields_for_type(investor_type)
        session["investor_type"] = investor_type

        # FIX A: strip _note and other private keys before flattening
        session["live_fill_flat"] = {
            k: v for k, v in flatten_dict(form_keys).items()
            if not k.startswith("_")
        }
        session["mandatory_flat"] = {
            k: v for k, v in flatten_dict(mandatory).items()
            if not k.startswith("_")
        }

        existing = session.pop("_pending_existing_data", None)
        if existing:
            for k, v in existing.items():
                if k in session["live_fill_flat"] and v not in (None, ""):
                    session["live_fill_flat"][k] = v

        if self.engine.pdf_workflow and session.get("pdf_path"):
            self.engine.pdf_workflow.trigger_prepare_async(
                user_id=user_id, session_id=session_id,
                pdf_path=session["pdf_path"], investor_type=investor_type,
            )

        msg = (
            f"Great, I'll collect information for a **{investor_type}** investor.\n\n"
            "Please share as much as you can — name, address, tax ID, contact details, etc."
        )
        self._log_turn(session, user_input, msg, State.INVESTOR_TYPE_SELECT.value)
        return msg, State.DATA_COLLECTION

    def _parse_selection(self, user_input):
        txt = user_input.strip()
        if txt.isdigit():
            idx = int(txt) - 1
            if 0 <= idx < len(INVESTOR_TYPES):
                return INVESTOR_TYPES[idx]
            return None
        match, score = fuzz_process.extractOne(txt, INVESTOR_TYPES)
        return match if score >= 70 else None