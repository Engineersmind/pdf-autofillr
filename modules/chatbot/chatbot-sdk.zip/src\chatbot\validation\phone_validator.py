# chatbot/validation/phone_validator.py
"""Phone number validation — matches Lambda validate_phone_format() behaviour."""
from __future__ import annotations
import re

# Matches Lambda: requires a country code prefix (+ or 00) followed by
# 10–15 digits (spaces, dashes, dots, parens allowed as separators).
# Examples that pass:  +1 212 555 1234,  +44-20-7946-0958,  001 212 5551234
# Examples that fail:  2125551234  (no country code),  123  (too short)
PHONE_WITH_COUNTRY_CODE_RE = re.compile(
    r"^\+?(?:00)?[\d]{1,4}[\s\-.]?"   # country code  (1–4 digits, optional +/00)
    r"[\d][\d\s\-.()]{8,14}$"          # subscriber number (min 8 more digits/separators)
)

# Loose fallback — used only for the normalise helper
PHONE_LOOSE_RE = re.compile(r"^\+?[\d\s\-().]{7,20}$")


def validate_phone(value: str) -> bool:
    """
    Return True if value looks like a valid international phone number.

    Requires a country code prefix matching Lambda's validate_phone_format():
    - Must start with + or 00 followed by country digits, OR
    - Must be long enough to contain a country code (min 11 digits total)
    """
    if not value:
        return False
    cleaned = re.sub(r"[\s\-.()+]", "", value.strip())
    # Must have at least 11 digits (country code + 10-digit number) or start with +/00
    has_prefix = value.strip().startswith("+") or value.strip().startswith("00")
    has_enough_digits = len(cleaned) >= 11
    if not (has_prefix or has_enough_digits):
        return False
    return bool(PHONE_WITH_COUNTRY_CODE_RE.match(value.strip()))


def normalise_phone(value: str) -> str:
    """Strip extra whitespace and normalise common separators."""
    return re.sub(r"\s+", " ", value.strip())


def split_phone_parts(value: str) -> dict:
    """
    Split a full phone number into country_code, part1, part2, part3.
    Mirrors Lambda's split_phone_or_fax() for internal PDF field population.

    Returns dict with keys: country_code, part1, part2, part3
    These are used ONLY when writing to internal split fields for PDF filling —
    never shown directly to the user.

    Examples:
        +1 212 555 1234  → {country_code: "1", part1: "212", part2: "555", part3: "1234"}
        +44 20 7946 0958 → {country_code: "44", part1: "20", part2: "7946", part3: "0958"}
    """
    cleaned = value.strip().lstrip("+")
    # Remove all non-digit/space/dash chars except keep structure
    digits_only = re.sub(r"[^\d]", " ", cleaned).split()

    if not digits_only:
        return {"country_code": "", "part1": "", "part2": "", "part3": ""}

    # Heuristic: first token is country code if total digit count >= 11
    all_digits = "".join(digits_only)
    if len(all_digits) >= 11:
        country_code = digits_only[0] if len(digits_only) > 1 else all_digits[:1]
        rest = digits_only[1:] if len(digits_only) > 1 else [all_digits[1:]]
    else:
        country_code = ""
        rest = digits_only

    # Pad rest to 3 parts
    while len(rest) < 3:
        rest.append("")

    return {
        "country_code": country_code,
        "part1": rest[0],
        "part2": rest[1],
        "part3": " ".join(rest[2:]) if len(rest) > 3 else rest[2],
    }