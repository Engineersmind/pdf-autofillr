# chatbot/entrypoints/cli.py
"""
chatbot-cli — interactive terminal session.

After `pip install pdf-autofillr-chatbot`:
    chatbot-cli
    chatbot-cli --pdf-path /path/to/blank.pdf --output filled.json --report
    chatbot-cli --message "single turn" --user-id u1 --session-id s1
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
import uuid
from pathlib import Path

from dotenv import load_dotenv
load_dotenv()

logger = logging.getLogger(__name__)


def parse_args():
    p = argparse.ArgumentParser(
        prog="chatbot-cli",
        description="pdf-autofillr-chatbot — conversational investor onboarding",
    )
    p.add_argument("--user-id",    default="cli_user")
    p.add_argument("--session-id", default=None)
    p.add_argument("--message",    default=None, help="Single message (non-interactive)")
    p.add_argument("--pdf-path",   default=None, help="Override pdf_path from config.ini")
    p.add_argument("--output",     default=None, help="Save filled data to this JSON file")
    p.add_argument("--report",     action="store_true", help="Print fill report on completion")
    p.add_argument("--log-level",  default="WARNING")
    p.add_argument("--config",     default=None, help="Path to config.ini (default: auto-detect)")
    return p.parse_args()


def build_client(settings):
    from chatbot import chatbotClient, LocalStorage, S3Storage, FormConfig

    if settings.storage_type == "s3":
        storage = S3Storage(
            output_bucket=settings.s3_output_bucket,
            config_bucket=settings.s3_config_bucket,
            region=settings.s3_region,
        )
        form_config = FormConfig.from_storage(storage)
    else:
        storage = LocalStorage(
            data_path=settings.data_path,
            config_path=settings.config_path,
        )
        form_config = FormConfig.from_directory(settings.config_path)

    pdf_filler = None
    if settings.pdf_filler_enabled:
        if settings.pdf_filler_provider == "mapper":
            from chatbot.pdf.mapper_filler import MapperPDFFiller
            pdf_filler = MapperPDFFiller(
                mapper_api_url=settings.mapper_api_url,
                mapper_api_key=settings.mapper_api_key,
            )
        elif settings.pdf_filler_provider == "managed":
            from chatbot_managed.filler import chatbotManagedPDFFiller
            import os
            pdf_filler = chatbotManagedPDFFiller(
                auth0_domain=os.environ["AUTH0_DOMAIN"],
                auth0_client_id=os.environ["AUTH0_CLIENT_ID"],
                auth0_client_secret=os.environ["AUTH0_CLIENT_SECRET"],
                auth0_audience=os.environ["AUTH0_AUDIENCE"],
                pdf_lambda_url=os.environ["FILL_PDF_LAMBDA_URL"],
                pdf_api_key=os.environ["PDF_API_KEY"],
                backend_url=os.getenv("BACKEND_URL", ""),
                auth_token=os.getenv("AUTH_TOKEN", ""),
            )
        # custom: pdf_filler stays None — files stored, user handles filling

    return chatbotClient(
        openai_api_key=settings.openai_api_key,
        storage=storage,
        form_config=form_config,
        pdf_filler=pdf_filler,
        settings=settings,
    )


def run_single_turn(args, settings):
    client = build_client(settings)
    session_id = args.session_id or str(uuid.uuid4())
    pdf_path = args.pdf_path or settings.pdf_path
    if pdf_path:
        client.create_session(args.user_id, session_id, pdf_path=pdf_path)
    response, complete, data = client.send_message(args.user_id, session_id, args.message)
    print(response)
    if complete:
        if args.output and data:
            Path(args.output).write_text(json.dumps(data, indent=2, default=str))
        if args.report:
            report = client.get_fill_report_text(args.user_id, session_id)
            if report:
                print("\n" + report, file=sys.stderr)


def run_interactive(args, settings):
    client = build_client(settings)
    session_id = args.session_id or str(uuid.uuid4())
    pdf_path = args.pdf_path or settings.pdf_path

    print("\n" + "=" * 60)
    print("  pdf-autofillr-chatbot")
    print("=" * 60)
    if pdf_path:
        print(f"  PDF: {pdf_path}")
    print(f"  Session: {session_id}")
    print(f"  Storage: {settings.storage_type}")
    if settings.pdf_filler_enabled:
        print(f"  PDF filler: {settings.pdf_filler_provider}")
    print("  Type 'exit' to quit.\n" + "-" * 60 + "\n")

    if pdf_path:
        client.create_session(args.user_id, session_id, pdf_path=pdf_path)

    response, complete, data = client.send_message(args.user_id, session_id, "")
    print(f"Bot: {response}\n")

    while not complete:
        try:
            user_input = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nSession ended.")
            break
        if user_input.lower() in ("exit", "quit", "q"):
            print("Session ended.")
            break
        response, complete, data = client.send_message(args.user_id, session_id, user_input)
        print(f"\nBot: {response}\n")

    if complete:
        print("\n" + "=" * 60 + "\n  Session complete!\n" + "=" * 60)
        if data:
            print(json.dumps(data, indent=2, default=str))
        if args.output and data:
            Path(args.output).write_text(json.dumps(data, indent=2, default=str))
            print(f"\n✅ Saved to: {args.output}")
        if args.report:
            report = client.get_fill_report_text(args.user_id, session_id)
            if report:
                print("\nFill Report:\n" + report)


def main():
    args = parse_args()
    logging.basicConfig(level=args.log_level)

    # Validate config before doing anything
    from chatbot.config.settings import Settings
    from chatbot.config.validator import validate_for_entrypoint

    try:
        settings = Settings(validate=False, config_ini_path=args.config)
        validate_for_entrypoint("cli", settings)
    except SystemExit:
        sys.exit(1)
    except EnvironmentError as e:
        print(f"\n❌ Config error:\n{e}", file=sys.stderr)
        sys.exit(1)

    try:
        if args.message is not None:
            run_single_turn(args, settings)
        else:
            run_interactive(args, settings)
    except Exception as e:
        logger.exception("Unexpected error")
        print(f"\n❌ Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()