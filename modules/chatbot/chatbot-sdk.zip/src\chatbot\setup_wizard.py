# modules/chatbot/src/chatbot/setup_wizard.py
"""
chatbot-setup — first-run and reconfiguration wizard.

After `pip install pdf-autofillr-chatbot`:
    chatbot-setup

Run any time to switch modes, enable/disable features, or reset.
"""
from __future__ import annotations

import configparser
import os
import shutil
import subprocess
import sys
from pathlib import Path


# ── Helpers ────────────────────────────────────────────────────────────────────

def _ask(prompt: str, default: str = "") -> str:
    display = f" [{default}]" if default else ""
    try:
        val = input(f"{prompt}{display}: ").strip()
    except (EOFError, KeyboardInterrupt):
        print("\nSetup cancelled.")
        sys.exit(0)
    return val if val else default


def _ask_choice(prompt: str, choices: list[str], default: str = "1") -> str:
    """Show numbered choices, return the chosen value (not the number)."""
    for i, c in enumerate(choices, 1):
        print(f"  {i}. {c}")
    raw = _ask(prompt, default)
    try:
        idx = int(raw) - 1
        if 0 <= idx < len(choices):
            return choices[idx]
    except ValueError:
        # allow typing the value directly
        if raw in choices:
            return raw
    return choices[int(default) - 1]


def _print_header(title: str) -> None:
    print("\n" + "=" * 60)
    print(f"  {title}")
    print("=" * 60)


def _read_ini(path: Path) -> configparser.ConfigParser:
    ini = configparser.ConfigParser()
    if path.exists():
        ini.read(path)
    return ini


def _write_ini(ini: configparser.ConfigParser, path: Path) -> None:
    with open(path, "w") as f:
        ini.write(f)


def _ini_get(ini: configparser.ConfigParser, section: str, key: str, fallback: str = "") -> str:
    try:
        return ini.get(section, key)
    except (configparser.NoSectionError, configparser.NoOptionError):
        return fallback


def _ini_set(ini: configparser.ConfigParser, section: str, key: str, value: str) -> None:
    if not ini.has_section(section):
        ini.add_section(section)
    ini.set(section, key, value)


def _read_env(path: Path) -> dict[str, str]:
    env: dict[str, str] = {}
    if not path.exists():
        return env
    for line in path.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, _, v = line.partition("=")
            env[k.strip()] = v.strip()
    return env


def _write_env(env: dict[str, str], path: Path) -> None:
    lines = []
    for k, v in env.items():
        lines.append(f"{k}={v}")
    path.write_text("\n".join(lines) + "\n")


def _drop_template_files(dest: Path) -> None:
    """Copy bundled .env.example and config.ini.example into dest."""
    pkg = Path(__file__).parent
    for fname in (".env.example", "config.ini.example"):
        src = pkg / fname
        dst = dest / fname
        if src.exists() and not dst.exists():
            shutil.copy(src, dst)
            print(f"  Created {dst.relative_to(dest.parent) if dest.parent != dest else dst}")


def _copy_configs(dest: Path) -> None:
    """Copy bundled config_samples/ → dest/configs/."""
    from chatbot import copy_sample_configs
    try:
        copy_sample_configs(str(dest))
    except FileNotFoundError as e:
        print(f"  ⚠ Could not copy configs: {e}")


def _download_source(dest: Path) -> None:
    """Download full modules/chatbot source into dest/modules/chatbot/."""
    target = dest / "modules" / "chatbot"
    if target.exists():
        print(f"  Source already exists at {target} — skipping download.")
        return

    # Try pip download first (works when installed from PyPI)
    print("  Downloading source...")
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "download",
             "--no-deps", "--no-binary", ":all:",
             "-d", str(dest / ".chatbot_src_tmp"),
             "pdf-autofillr-chatbot"],
            capture_output=True, text=True, timeout=60,
        )
        if result.returncode == 0:
            import glob, tarfile, zipfile
            archives = (
                glob.glob(str(dest / ".chatbot_src_tmp" / "*.tar.gz"))
                + glob.glob(str(dest / ".chatbot_src_tmp" / "*.zip"))
            )
            if archives:
                target.mkdir(parents=True, exist_ok=True)
                archive = archives[0]
                if archive.endswith(".tar.gz"):
                    with tarfile.open(archive) as tf:
                        tf.extractall(str(dest / ".chatbot_src_tmp" / "extracted"))
                else:
                    with zipfile.ZipFile(archive) as zf:
                        zf.extractall(str(dest / ".chatbot_src_tmp" / "extracted"))
                # move src/chatbot → modules/chatbot/src/chatbot
                extracted_roots = list((dest / ".chatbot_src_tmp" / "extracted").iterdir())
                if extracted_roots:
                    shutil.copytree(str(extracted_roots[0]), str(target), dirs_exist_ok=True)
                shutil.rmtree(str(dest / ".chatbot_src_tmp"), ignore_errors=True)
                print(f"  ✅ Source downloaded to {target}")
                return
    except Exception:
        pass

    # Fallback: the package is already installed — copy from site-packages
    import chatbot as _chatbot_pkg
    pkg_root = Path(_chatbot_pkg.__file__).parent
    # go up to the installed package root
    src_root = pkg_root.parent  # site-packages/chatbot → site-packages
    target.mkdir(parents=True, exist_ok=True)
    shutil.copytree(str(pkg_root), str(target / "src" / "chatbot"), dirs_exist_ok=True)
    print(f"  ✅ Source copied from installed package to {target}")
    print(f"  To use your edited source:  pip install -e {target}")


# ── Main wizard sections ───────────────────────────────────────────────────────

def _section_edit_mode(cwd: Path, ini: configparser.ConfigParser, existing: bool) -> bool:
    """Returns True if edit mode is on."""
    if existing:
        # Cannot change edit_mode after first setup
        return _ini_get(ini, "core", "edit_mode", "false").lower() == "true"

    print("\n── Source code ───────────────────────────────────────────────")
    print("Do you want to edit the chatbot source code?")
    print("  y → downloads modules/chatbot/ into your working directory")
    print("  n → library mode only (.env, config.ini, configs/ created)")
    choice = _ask("Edit source? (y/n)", "n").lower()
    return choice == "y"


def _section_mode(ini: configparser.ConfigParser) -> str:
    print("\n── Run mode ──────────────────────────────────────────────────")
    print("How do you want to run the chatbot?")
    current = _ini_get(ini, "core", "mode", "server")
    choices = ["server", "cli", "lambda", "embed", "library"]
    default_idx = str(choices.index(current) + 1) if current in choices else "1"
    return _ask_choice("Choice", choices, default_idx)


def _section_storage(ini: configparser.ConfigParser, env: dict) -> str:
    print("\n── Storage ───────────────────────────────────────────────────")
    print("Where should session data be stored?")
    current = _ini_get(ini, "core", "storage", "local")
    choices = ["local", "s3"]
    default_idx = str(choices.index(current) + 1) if current in choices else "1"
    storage = _ask_choice("Choice", choices, default_idx)

    if storage == "local":
        data_path = _ask("Session data directory", _ini_get(ini, "storage_local", "data_path", "./chatbot_data"))
        config_path = _ask("Config files directory", _ini_get(ini, "storage_local", "config_path", "./configs"))
        _ini_set(ini, "storage_local", "data_path", data_path)
        _ini_set(ini, "storage_local", "config_path", config_path)

    elif storage == "s3":
        output_bucket = _ask("AWS Output Bucket", _ini_get(ini, "storage_s3", "output_bucket", ""))
        config_bucket = _ask("AWS Config Bucket", _ini_get(ini, "storage_s3", "config_bucket", ""))
        region = _ask("AWS Region", _ini_get(ini, "storage_s3", "region", "us-east-1"))
        _ini_set(ini, "storage_s3", "output_bucket", output_bucket)
        _ini_set(ini, "storage_s3", "config_bucket", config_bucket)
        _ini_set(ini, "storage_s3", "region", region)

        print("\n  AWS credentials — choose ONE:")
        print("  1. Access key pair (stored in .env)")
        print("  2. IAM role / AWS_PROFILE (no keys needed)")
        cred_choice = _ask("Choice", "2")
        if cred_choice == "1":
            env["AWS_ACCESS_KEY_ID"]     = _ask("AWS Access Key ID",     env.get("AWS_ACCESS_KEY_ID", ""))
            env["AWS_SECRET_ACCESS_KEY"] = _ask("AWS Secret Access Key", env.get("AWS_SECRET_ACCESS_KEY", ""))
        else:
            profile = _ask("AWS_PROFILE (leave blank to use instance role)", env.get("AWS_PROFILE", ""))
            if profile:
                env["AWS_PROFILE"] = profile

    return storage


def _section_pdf_filler(ini: configparser.ConfigParser, env: dict) -> tuple[bool, str]:
    print("\n── PDF filler ────────────────────────────────────────────────")
    print("Enable PDF filling after conversation completes?")
    print("  1. no      — collect and store data only")
    print("  2. mapper  — self-hosted mapper module")
    print("  3. managed — pdf-autofillr managed service")
    print("  4. custom  — store files only, you handle filling yourself")

    current_enabled  = _ini_get(ini, "pdf_filler", "enabled", "false").lower() == "true"
    current_provider = _ini_get(ini, "pdf_filler", "provider", "mapper")

    if not current_enabled:
        current_default = "1"
    elif current_provider == "mapper":
        current_default = "2"
    elif current_provider == "managed":
        current_default = "3"
    else:
        current_default = "4"

    choice = _ask("Choice", current_default)
    choice_map = {"1": (False, "mapper"), "2": (True, "mapper"),
                  "3": (True, "managed"), "4": (True, "custom")}
    enabled, provider = choice_map.get(choice, (False, "mapper"))

    if enabled:
        pdf_path = _ask(
            "Path to blank PDF (local path or s3://...)",
            _ini_get(ini, "pdf_filler", "pdf_path", ""),
        )
        _ini_set(ini, "pdf_filler", "pdf_path", pdf_path)

        if provider == "mapper":
            api_url = _ask("Mapper API URL", _ini_get(ini, "mapper", "api_url", "http://localhost:8000"))
            url_prefix = _ask("Mapper URL prefix", _ini_get(ini, "mapper", "url_prefix", "/mapper"))
            _ini_set(ini, "mapper", "api_url", api_url)
            _ini_set(ini, "mapper", "url_prefix", url_prefix)
            env["MAPPER_API_KEY"] = _ask("Mapper API key (blank = no auth)", env.get("MAPPER_API_KEY", ""))

        elif provider == "managed":
            print("\n  Managed service credentials (go in .env):")
            for key in ["AUTH0_DOMAIN", "AUTH0_CLIENT_ID", "AUTH0_CLIENT_SECRET",
                        "AUTH0_AUDIENCE", "FILL_PDF_LAMBDA_URL", "PDF_API_KEY"]:
                env[key] = _ask(f"  {key}", env.get(key, ""))

    _ini_set(ini, "pdf_filler", "enabled", str(enabled).lower())
    _ini_set(ini, "pdf_filler", "provider", provider)
    return enabled, provider


def _section_telemetry(ini: configparser.ConfigParser, env: dict, provider: str) -> None:
    # managed provider forces managed telemetry — no question needed
    if provider == "managed":
        _ini_set(ini, "telemetry", "mode", "managed")
        print("\n── Telemetry ─────────────────────────────────────────────────")
        print("  (managed pdf_filler — telemetry.mode automatically set to managed)")
        env["chatbot_SDK_API_KEY"] = _ask(
            "  chatbot SDK API key",
            env.get("chatbot_SDK_API_KEY", ""),
        )
        return

    print("\n── Telemetry ─────────────────────────────────────────────────")
    print("Telemetry mode:")
    print("  1. local   — disabled / send to your own endpoint")
    print("  2. managed — pdf-autofillr managed service (requires managed pdf_filler)")
    current = _ini_get(ini, "telemetry", "mode", "local")
    default = "1" if current == "local" else "2"
    choice = _ask("Choice", default)

    if choice == "2":
        print("  ⚠  managed telemetry requires pdf_filler.provider = managed.")
        print("     Keeping local mode.")
        _ini_set(ini, "telemetry", "mode", "local")
    else:
        _ini_set(ini, "telemetry", "mode", "local")
        endpoint = _ask("Telemetry endpoint (blank = disabled)", env.get("TELEMETRY_ENDPOINT", ""))
        if endpoint:
            env["TELEMETRY_ENDPOINT"] = endpoint


def _section_openai(env: dict) -> None:
    print("\n── API keys ──────────────────────────────────────────────────")
    current = env.get("OPENAI_API_KEY", "")
    display = f"sk-...{current[-4:]}" if len(current) > 8 else ("(set)" if current else "")
    new_val = _ask(f"OpenAI API key", display)
    if new_val and not new_val.startswith("sk-..."):
        env["OPENAI_API_KEY"] = new_val


def _print_run_instructions(mode: str, port: str) -> None:
    print("\n── How to run ────────────────────────────────────────────────")
    if mode == "server":
        print(f"  chatbot-server")
        print(f"  # or: uvicorn chatbot.entrypoints.fastapi_app:app --port {port}")
    elif mode == "cli":
        print("  chatbot-cli")
    elif mode == "lambda":
        print("  Lambda handler: chatbot.entrypoints.aws_lambda.handler")
        print("  Set all .env values as Lambda environment variables.")
    elif mode == "embed":
        print("  from chatbot.entrypoints.fastapi_app import app as chatbot_app")
        print("  main_app.mount(\"/onboarding\", chatbot_app)")
    elif mode == "library":
        print("  from chatbot import chatbotClient, LocalStorage, FormConfig")
        print("  # See README for full example")


# ── Entry point ────────────────────────────────────────────────────────────────

def main() -> None:
    from dotenv import load_dotenv
    load_dotenv()

    cwd = Path.cwd()
    ini_path = cwd / "config.ini"
    env_path = cwd / ".env"

    existing = ini_path.exists()

    _print_header("pdf-autofillr-chatbot — Setup")
    if existing:
        print("  config.ini found — re-running setup.")
        print("  Press Enter to keep current values.\n")
        print("  Options:")
        print("  1. Reconfigure (keep edit_mode, change everything else)")
        print("  2. Reset (delete config.ini and .env, start fresh)")
        print("  3. Exit")
        choice = _ask("Choice", "1")
        if choice == "3":
            sys.exit(0)
        if choice == "2":
            ini_path.unlink(missing_ok=True)
            env_path.unlink(missing_ok=True)
            existing = False
            print("  Deleted config.ini and .env — starting fresh.\n")
    else:
        print()

    ini = _read_ini(ini_path)
    env = _read_env(env_path)

    # ── Edit mode (first run only) ─────────────────────────────────────
    edit_mode = _section_edit_mode(cwd, ini, existing)
    _ini_set(ini, "core", "edit_mode", str(edit_mode).lower())

    # ── Mode ──────────────────────────────────────────────────────────
    mode = _section_mode(ini)
    _ini_set(ini, "core", "mode", mode)

    # ── Storage ───────────────────────────────────────────────────────
    storage = _section_storage(ini, env)
    _ini_set(ini, "core", "storage", storage)

    # ── Server port (only if server mode) ─────────────────────────────
    port = _ini_get(ini, "server", "port", "8001")
    if mode == "server":
        port = _ask("Server port", port)
        _ini_set(ini, "server", "port", port)
        _ini_set(ini, "server", "host", _ask("Server host", _ini_get(ini, "server", "host", "0.0.0.0")))

    # ── PDF filler ────────────────────────────────────────────────────
    _, provider = _section_pdf_filler(ini, env)

    # ── Telemetry ─────────────────────────────────────────────────────
    _section_telemetry(ini, env, provider)

    # ── OpenAI key ────────────────────────────────────────────────────
    _section_openai(env)

    # ── Write files ───────────────────────────────────────────────────
    print("\n── Writing files ─────────────────────────────────────────────")
    _write_ini(ini, ini_path)
    print(f"  ✅ config.ini")

    _write_env(env, env_path)
    print(f"  ✅ .env")

    if not (cwd / "configs").exists():
        _copy_configs(cwd)
        print(f"  ✅ configs/")

    if not existing:
        _drop_template_files(cwd)

    if edit_mode and not existing:
        _download_source(cwd)

    # ── Done ──────────────────────────────────────────────────────────
    _print_header("Setup complete!")
    print(f"  config.ini  ← behaviour config (safe to commit to git)")
    print(f"  .env        ← secrets (DO NOT commit)")
    print(f"  configs/    ← form field configs (edit to customise)")

    if provider == "mapper":
        print(f"\n  ⚠  Make sure mapper is running before starting:")
        print(f"     cd modules/mapper && python api_server.py")

    _print_run_instructions(mode, port)
    print(f"\n  Re-run `chatbot-setup` any time to switch modes.\n")