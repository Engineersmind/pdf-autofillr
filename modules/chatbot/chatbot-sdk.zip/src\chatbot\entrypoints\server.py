# chatbot/entrypoints/server.py
"""
chatbot-server — starts the FastAPI API server.

After `pip install pdf-autofillr-chatbot`:
    chatbot-server

Config is read from config.ini (if present) then .env.
All behaviour is controlled by config.ini — no need to pass flags.
"""
from __future__ import annotations

import sys

from dotenv import load_dotenv
load_dotenv()


def main():
    try:
        import uvicorn
    except ImportError:
        print(
            "❌ uvicorn is not installed.\n"
            "   Run: pip install 'pdf-autofillr-chatbot[server]'",
            file=sys.stderr,
        )
        sys.exit(1)

    # Validate before importing the app (app-level imports trigger client init)
    from chatbot.config.settings import Settings
    from chatbot.config.validator import validate_for_entrypoint

    try:
        settings = Settings(validate=False)
        validate_for_entrypoint("server", settings)
    except SystemExit:
        sys.exit(1)
    except EnvironmentError as e:
        print(f"\n❌ Config error:\n{e}", file=sys.stderr)
        sys.exit(1)

    from chatbot.entrypoints.fastapi_app import app

    host    = settings.server_host
    port    = int(settings.server_port)
    workers = int(settings.server_workers)
    log_level = settings.log_level.lower()

    print(f"\n🚀 pdf-autofillr-chatbot API → http://{host}:{port}")
    print(f"   Docs:     http://localhost:{port}/docs")
    print(f"   Storage:  {settings.storage_type}")
    if settings.pdf_filler_enabled:
        print(f"   PDF fill: {settings.pdf_filler_provider} → {settings.pdf_path}")
    else:
        print(f"   PDF fill: disabled (data collection only)")
    print(f"   Telemetry: {settings.telemetry_mode}\n")

    uvicorn.run(
        app,
        host=host,
        port=port,
        workers=workers,
        log_level=log_level,
    )


if __name__ == "__main__":
    main()