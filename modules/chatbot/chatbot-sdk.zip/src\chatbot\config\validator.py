# chatbot/config/validator.py
"""
ConfigValidator — checks that all deps and config values are present
for the active entrypoint before anything starts.

Called at the top of every entrypoint (cli, server, lambda, embed, library).
Fails fast with a clear actionable message if anything is missing.
"""
from __future__ import annotations

import importlib
import os
import sys
from pathlib import Path

from chatbot.config.settings import Settings


class ConfigError(SystemExit):
    """Raised when configuration is invalid. Exits with code 1."""
    pass


def _check_import(package: str, install_hint: str) -> str | None:
    """Return error string if package not importable, else None."""
    try:
        importlib.import_module(package)
        return None
    except ImportError:
        return f"Missing package: {package}\n  Install: {install_hint}"


def _check_path_exists(path: str, label: str) -> str | None:
    """Return error string if local path does not exist."""
    if not Path(path).exists():
        return (
            f"{label} not found: {path}\n"
            f"  Run: python -c \"import chatbot; chatbot.copy_sample_configs('.')\" "
            f"to create it."
        )
    return None


def validate_for_entrypoint(entrypoint: str, settings: Settings | None = None) -> None:
    """
    Validate config and dependencies for the given entrypoint.

    Args:
        entrypoint: one of "cli" | "server" | "lambda" | "embed" | "library"
        settings:   optional pre-built Settings instance (built fresh if None)

    Raises:
        ConfigError (SystemExit 1) if any required dep or config is missing.
        Prints warnings for non-fatal issues.
    """
    s = settings or Settings(validate=False)   # raw load, we do our own checks here
    errors: list[str] = []
    warns: list[str] = []

    # ── Always required ────────────────────────────────────────────────
    if not s.openai_api_key:
        errors.append(
            "OPENAI_API_KEY is not set.\n"
            "  Add it to your .env:  OPENAI_API_KEY=sk-..."
        )

    # ── Storage ────────────────────────────────────────────────────────
    if s.storage_type == "local":
        err = _check_path_exists(s.config_path, "config_path")
        if err:
            errors.append(err)
        # data_path is auto-created, just warn if parent doesn't exist
        parent = Path(s.data_path).parent
        if not parent.exists():
            warns.append(f"data_path parent does not exist: {parent} — it will be created.")

    elif s.storage_type == "s3":
        err = _check_import("boto3", "pip install pdf-autofillr-chatbot[s3]")
        if err:
            errors.append(err)
        if not s.s3_output_bucket:
            errors.append(
                "storage_s3.output_bucket is empty.\n"
                "  Set it in config.ini [storage_s3] or AWS_OUTPUT_BUCKET env var."
            )
        if not s.s3_config_bucket:
            errors.append(
                "storage_s3.config_bucket is empty.\n"
                "  Set it in config.ini [storage_s3] or AWS_CONFIG_BUCKET env var."
            )
        has_creds = (
            os.getenv("AWS_ACCESS_KEY_ID")
            or os.getenv("AWS_PROFILE")
            or os.getenv("AWS_ROLE_ARN")
            or os.getenv("AWS_EXECUTION_ENV")
            or os.getenv("AWS_LAMBDA_FUNCTION_NAME")
        )
        if not has_creds:
            errors.append(
                "No AWS credentials found.\n"
                "  Set AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY in .env,\n"
                "  or use AWS_PROFILE, or attach an IAM role."
            )
        # Lambda with local storage — warn only
        if entrypoint == "lambda" and s.storage_type == "local":
            warns.append(
                "core.mode = lambda with storage = local — /tmp is ephemeral.\n"
                "  Set core.storage = s3 for persistent storage in Lambda."
            )

    # ── Entrypoint-specific ────────────────────────────────────────────
    if entrypoint in ("server", "embed"):
        err = _check_import("fastapi", "pip install pdf-autofillr-chatbot[server]")
        if err:
            errors.append(err)
        err = _check_import("uvicorn", "pip install pdf-autofillr-chatbot[server]")
        if err:
            errors.append(err)
        try:
            port = int(s.server_port)
            if not (1 <= port <= 65535):
                raise ValueError
        except (ValueError, TypeError):
            errors.append(f"server.port is invalid: {s.server_port!r} — must be 1-65535")

    # ── PDF filler ─────────────────────────────────────────────────────
    if s.pdf_filler_enabled:
        if not s.pdf_path:
            errors.append(
                "pdf_filler.enabled = true but pdf_filler.pdf_path is not set.\n"
                "  Set it in config.ini [pdf_filler] pdf_path = ./data/blank.pdf"
            )

        if s.pdf_filler_provider == "mapper":
            err = _check_import("httpx", "pip install pdf-autofillr-chatbot[mapper]")
            if err:
                errors.append(err)
            # pdf-autofiller-sdk may be named pdf_autofiller or similar
            try:
                importlib.import_module("pdf_autofiller")
            except ImportError:
                errors.append(
                    "Missing package: pdf-autofiller-sdk\n"
                    "  Install: pip install pdf-autofiller-sdk"
                )
            if not s.mapper_api_url:
                errors.append(
                    "mapper.api_url is not set.\n"
                    "  Set it in config.ini [mapper] api_url = http://localhost:8000"
                )
            else:
                # Warn (not error) if mapper unreachable — it may start after us
                try:
                    import httpx
                    resp = httpx.get(f"{s.mapper_api_url}/health", timeout=2.0)
                    if resp.status_code != 200:
                        warns.append(
                            f"Mapper health check returned HTTP {resp.status_code}.\n"
                            f"  Make sure mapper is running: cd modules/mapper && python api_server.py"
                        )
                except Exception:
                    warns.append(
                        f"Cannot reach mapper at {s.mapper_api_url}/health.\n"
                        f"  Make sure mapper is running: cd modules/mapper && python api_server.py\n"
                        f"  (This is a warning — chatbot will start anyway.)"
                    )

        elif s.pdf_filler_provider == "managed":
            err = _check_import("httpx", "pip install pdf-autofillr-chatbot[managed]")
            if err:
                errors.append(err)
            try:
                importlib.import_module("chatbot_managed")
            except ImportError:
                errors.append(
                    "Missing package: chatbot-managed\n"
                    "  This is a private package — contact the team for access."
                )
            required_env = [
                "AUTH0_DOMAIN", "AUTH0_CLIENT_ID", "AUTH0_CLIENT_SECRET",
                "AUTH0_AUDIENCE", "FILL_PDF_LAMBDA_URL", "PDF_API_KEY",
            ]
            missing = [v for v in required_env if not os.getenv(v)]
            if missing:
                errors.append(
                    "pdf_filler.provider = managed but these .env keys are missing:\n"
                    + "\n".join(f"  - {v}" for v in missing)
                )

    # ── Telemetry ──────────────────────────────────────────────────────
    if s.telemetry_enabled:
        if s.telemetry_mode == "local" and not s.telemetry_endpoint:
            warns.append(
                "telemetry.mode = local but TELEMETRY_ENDPOINT is not set.\n"
                "  Events will be queued but never sent."
            )
        if s.telemetry_mode == "managed":
            if s.pdf_filler_provider != "managed":
                errors.append(
                    "telemetry.mode = managed requires pdf_filler.provider = managed."
                )
            if not s.sdk_api_key:
                errors.append(
                    "telemetry.mode = managed but chatbot_SDK_API_KEY is not set in .env."
                )

    # ── Emit ───────────────────────────────────────────────────────────
    _emit(errors, warns, entrypoint)


def _emit(errors: list[str], warns: list[str], entrypoint: str) -> None:
    for w in warns:
        print(f"\n⚠️  [chatbot-setup] {w}", file=sys.stderr)

    if errors:
        print(f"\n❌ Cannot start {entrypoint!r} — fix the following:\n", file=sys.stderr)
        for i, e in enumerate(errors, 1):
            print(f"  {i}. {e}\n", file=sys.stderr)
        print("  Run `chatbot-setup` to reconfigure interactively.\n", file=sys.stderr)
        raise ConfigError(1)