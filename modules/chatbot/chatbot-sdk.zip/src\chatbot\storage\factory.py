# chatbot/storage/factory.py
"""StorageFactory — creates the correct backend from Settings."""
from __future__ import annotations

from chatbot.storage.base import StorageBackend


class StorageFactory:
    @staticmethod
    def from_settings(settings=None) -> StorageBackend:
        """
        Build a StorageBackend from a Settings instance.
        If settings is None, builds one fresh from config.ini + env.
        """
        if settings is None:
            from chatbot.config.settings import Settings
            settings = Settings(validate=False)

        if settings.storage_type == "s3":
            from chatbot.storage.s3_storage import S3Storage
            return S3Storage(
                output_bucket=settings.s3_output_bucket,
                config_bucket=settings.s3_config_bucket,
                region=settings.s3_region,
            )
        else:
            from chatbot.storage.local_storage import LocalStorage
            return LocalStorage(
                data_path=settings.data_path,
                config_path=settings.config_path,
            )

    @staticmethod
    def create(storage_type: str = None, **kwargs) -> StorageBackend:
        """
        Legacy method — still works if called with explicit kwargs.
        Prefer from_settings() for new code.
        """
        import os
        storage_type = storage_type or os.getenv("chatbot_STORAGE", "local")

        if storage_type == "local":
            from chatbot.storage.local_storage import LocalStorage
            return LocalStorage(
                data_path=kwargs.get("data_path", os.getenv("chatbot_DATA_PATH", "./chatbot_data")),
                config_path=kwargs.get("config_path", os.getenv("chatbot_CONFIG_PATH", "./configs")),
            )
        elif storage_type == "s3":
            from chatbot.storage.s3_storage import S3Storage
            return S3Storage(
                output_bucket=kwargs.get("output_bucket", os.environ["AWS_OUTPUT_BUCKET"]),
                config_bucket=kwargs.get("config_bucket", os.environ["AWS_CONFIG_BUCKET"]),
                region=kwargs.get("region", os.getenv("AWS_REGION", "us-east-1")),
            )
        else:
            raise ValueError(f"Unknown storage type: {storage_type!r}. Use 'local' or 's3'.")